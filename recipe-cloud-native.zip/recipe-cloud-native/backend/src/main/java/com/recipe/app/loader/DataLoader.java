package com.recipe.app.loader;

import com.recipe.app.model.Category;
import com.recipe.app.model.Recipe;
import com.recipe.app.repository.RecipeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class DataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataLoader.class);

    private final RecipeRepository recipeRepository;

    public DataLoader(RecipeRepository recipeRepository) {
        this.recipeRepository = recipeRepository;
    }

    @Override
    public void run(String... args) {
        if (recipeRepository.count() == 0) {
            log.info("Populating initial cloud-native recipe dataset...");

            Recipe r1 = new Recipe(
                    "Mediterranean Grilled Salmon",
                    "Fresh wild salmon fillets marinated in lemon, garlic, olive oil, and aromatic fresh herbs, grilled to flaky perfection.",
                    Category.DINNER,
                    Arrays.asList(
                            "4 wild-caught salmon fillets",
                            "3 tbsp extra virgin olive oil",
                            "2 cloves minced garlic",
                            "Juice and zest of 1 fresh lemon",
                            "1 tsp dried oregano",
                            "1/2 tsp smoked paprika",
                            "Salt and freshly cracked black pepper",
                            "Fresh dill and lemon wedges for serving"
                    ),
                    "1. In a small bowl, whisk together olive oil, lemon juice, lemon zest, minced garlic, oregano, paprika, salt, and pepper.\n" +
                    "2. Place salmon fillets in a shallow dish, pour marinade over them, and let rest for 15-20 minutes.\n" +
                    "3. Preheat grill or grill pan over medium-high heat (around 400°F / 200°C) and oil the grates.\n" +
                    "4. Grill salmon skin-side down for 4-5 minutes, carefully flip, and grill for another 3-4 minutes until cooked through and opaque.\n" +
                    "5. Garnish with fresh dill and serve immediately with grilled asparagus or quinoa.",
                    15, 10, 4, "Easy",
                    "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=800&q=80",
                    "Chef Sophia Vance"
            );

            Recipe r2 = new Recipe(
                    "Avocado Sourdough Toast with Poached Egg",
                    "Artisanal toasted sourdough bread topped with creamy mashed avocado, chili flakes, microgreens, and a silky soft-poached farm egg.",
                    Category.BREAKFAST,
                    Arrays.asList(
                            "2 thick slices artisanal sourdough bread",
                            "1 ripe Haas avocado",
                            "2 organic free-range eggs",
                            "1 tbsp white vinegar (for poaching)",
                            "1/2 tsp red pepper flakes",
                            "1 tbsp toasted pumpkin seeds",
                            "Flaky sea salt and black pepper",
                            "Handful of fresh microgreens or cilantro"
                    ),
                    "1. Toast sourdough slices until golden and crisp.\n" +
                    "2. Cut avocado in half, remove pit, scoop into a bowl, and lightly mash with lemon juice, salt, and black pepper.\n" +
                    "3. Bring a small pot of water to a gentle simmer, add vinegar, and swirl into a gentle whirlpool.\n" +
                    "4. Crack egg into a ramekin and gently slide into the center; poach for 3 minutes for a runny yolk.\n" +
                    "5. Spread mashed avocado evenly onto warm sourdough toasts, top each with a warm poached egg, sprinkle chili flakes and microgreens.",
                    10, 5, 2, "Easy",
                    "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=800&q=80",
                    "Chef Marco Rossi"
            );

            Recipe r3 = new Recipe(
                    "Creamy Tuscan Garlic Chicken",
                    "Tender golden chicken breasts simmered in a rich garlic cream sauce with sun-dried tomatoes, baby spinach, and aged parmesan.",
                    Category.DINNER,
                    Arrays.asList(
                            "2 large boneless skinless chicken breasts (halved horizontally)",
                            "1 tbsp olive oil",
                            "2 tbsp unsalted butter",
                            "4 cloves minced garlic",
                            "1 cup heavy cream",
                            "1/2 cup low-sodium chicken broth",
                            "1/2 cup sun-dried tomatoes (chopped)",
                            "2 cups fresh baby spinach leaves",
                            "1/2 cup freshly grated Parmesan cheese"
                    ),
                    "1. Season chicken cutlets with Italian seasoning, salt, and black pepper.\n" +
                    "2. Heat olive oil and 1 tbsp butter in a large skillet over medium-high heat. Sear chicken 5 minutes per side until golden; remove and set aside.\n" +
                    "3. In the same skillet, melt remaining butter and sauté minced garlic for 1 minute until fragrant.\n" +
                    "4. Pour in chicken broth, heavy cream, sun-dried tomatoes, and simmer for 3 minutes.\n" +
                    "5. Stir in baby spinach and Parmesan until spinach wilts and sauce thickens.\n" +
                    "6. Return chicken to skillet and spoon sauce over chicken. Serve warm over fettuccine or mashed potatoes.",
                    15, 20, 4, "Medium",
                    "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&w=800&q=80",
                    "Chef Elena Rostova"
            );

            Recipe r4 = new Recipe(
                    "Rainbow Quinoa Buddha Bowl",
                    "A vibrant plant-based bowl packed with fluffy tri-color quinoa, roasted chickpeas, avocado, shredded purple cabbage, and tahini-maple drizzle.",
                    Category.VEGAN,
                    Arrays.asList(
                            "1 cup cooked tri-color quinoa",
                            "1 can (15 oz) chickpeas, rinsed and roasted with cumin & paprika",
                            "1 cup shredded purple cabbage",
                            "1 cup roasted sweet potato cubes",
                            "1 ripe avocado, sliced",
                            "1/2 cup edamame beans",
                            "3 tbsp tahini",
                            "1 tbsp pure maple syrup",
                            "2 tbsp warm water to thin dressing",
                            "1 tbsp lemon juice"
                    ),
                    "1. Roast chickpeas and cubed sweet potatoes at 400°F (200°C) with olive oil, cumin, smoked paprika, and salt for 25 minutes.\n" +
                    "2. Cook quinoa according to package instructions with a pinch of sea salt.\n" +
                    "3. In a small jar, shake tahini, maple syrup, lemon juice, warm water, and garlic powder until smooth.\n" +
                    "4. Assemble bowls: place a base of fluffy quinoa, arrange sweet potatoes, roasted chickpeas, purple cabbage, edamame, and sliced avocado in vibrant sections.\n" +
                    "5. Drizzle generously with tahini dressing and garnish with sesame seeds.",
                    15, 25, 2, "Easy",
                    "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80",
                    "Chef Maya Lin"
            );

            Recipe r5 = new Recipe(
                    "Classic Italian Tiramisu",
                    "The legendary Italian dessert crafted with delicate espresso-soaked ladyfingers, velvety mascarpone cream, and dusted with rich Dutch cocoa.",
                    Category.DESSERT,
                    Arrays.asList(
                            "6 large egg yolks",
                            "3/4 cup granulated sugar",
                            "16 oz mascarpone cheese (room temperature)",
                            "1 1/2 cups heavy whipping cream",
                            "1 1/2 cups freshly brewed strong espresso (cooled)",
                            "2 tbsp dark rum or coffee liqueur",
                            "24-30 Italian Savoiardi ladyfingers",
                            "Unsweetened Dutch cocoa powder for dusting"
                    ),
                    "1. Whisk egg yolks and sugar over a gentle double boiler for 6-8 minutes until pale, thick, and sugar is completely dissolved; let cool slightly.\n" +
                    "2. Beat mascarpone into yolk mixture until velvety and smooth.\n" +
                    "3. In a separate bowl, whip heavy cream to stiff peaks; gently fold into mascarpone mixture.\n" +
                    "4. Combine cooled espresso and rum. Quickly dip each ladyfinger (1 second per side) and arrange in single layer in an 8x8 baking dish.\n" +
                    "5. Spread half of mascarpone cream over ladyfingers. Repeat with second layer of dipped ladyfingers and remaining cream.\n" +
                    "6. Cover and refrigerate for at least 6 hours (preferably overnight). Dust generously with Dutch cocoa powder before slicing.",
                    30, 0, 8, "Medium",
                    "https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?auto=format&fit=crop&w=800&q=80",
                    "Chef Gianluca Conti"
            );

            Recipe r6 = new Recipe(
                    "15-Minute Garlic Butter Shrimp Scampi",
                    "Succulent jumbo shrimp sautéed in fragrant garlic butter, white wine, crushed red pepper flakes, and tossed with fresh parsley and angel hair.",
                    Category.QUICK_EASY,
                    Arrays.asList(
                            "1 lb large peeled & deveined shrimp",
                            "8 oz angel hair pasta or linguine",
                            "4 tbsp unsalted butter",
                            "2 tbsp olive oil",
                            "5 cloves minced garlic",
                            "1/3 cup dry white wine or chicken broth",
                            "Juice of half a lemon",
                            "1/4 cup chopped fresh flat-leaf parsley",
                            "Pinch of red pepper flakes and salt"
                    ),
                    "1. Bring a pot of salted water to boil; cook angel hair pasta al dente (about 4-5 minutes) and reserve 1/2 cup pasta water.\n" +
                    "2. In a large skillet, heat olive oil and 2 tbsp butter over medium-high heat. Add shrimp, season with salt and pepper, cook for 1.5 minutes per side until pink; transfer to plate.\n" +
                    "3. Add remaining butter and minced garlic to skillet, sauté 30 seconds until fragrant.\n" +
                    "4. Deglaze pan with white wine and lemon juice, simmering for 2 minutes.\n" +
                    "5. Return shrimp to skillet along with drained pasta and fresh parsley. Toss vigorously, adding splash of pasta water if needed to coat.",
                    5, 10, 4, "Easy",
                    "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=800&q=80",
                    "Chef Alex Turner"
            );

            recipeRepository.saveAll(List.of(r1, r2, r3, r4, r5, r6));
            log.info("Initialized {} starter recipes successfully!", recipeRepository.count());
        }
    }
}
