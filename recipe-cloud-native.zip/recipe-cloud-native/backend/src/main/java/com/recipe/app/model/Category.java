package com.recipe.app.model;

public enum Category {
    BREAKFAST,
    LUNCH,
    DINNER,
    DESSERT,
    SNACK,
    VEGAN,
    QUICK_EASY
}
