package com.recipe.app.service;

import com.recipe.app.dto.RecipeRequest;
import com.recipe.app.dto.RecipeResponse;
import com.recipe.app.model.Category;

import java.util.List;
import java.util.Map;

public interface RecipeService {
    List<RecipeResponse> getAllRecipes(Category category, String keyword);
    RecipeResponse getRecipeById(Long id);
    RecipeResponse createRecipe(RecipeRequest request);
    RecipeResponse updateRecipe(Long id, RecipeRequest request);
    void deleteRecipe(Long id);
    Map<String, Object> getRecipeStats();
}
