package com.recipe.app.service;

import com.recipe.app.dto.RecipeRequest;
import com.recipe.app.dto.RecipeResponse;
import com.recipe.app.exception.ResourceNotFoundException;
import com.recipe.app.model.Category;
import com.recipe.app.model.Recipe;
import com.recipe.app.repository.RecipeRepository;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Timer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
public class RecipeServiceImpl implements RecipeService {

    private static final Logger log = LoggerFactory.getLogger(RecipeServiceImpl.class);

    private final RecipeRepository recipeRepository;
    private final Counter recipesCreatedCounter;
    private final Counter recipesDeletedCounter;
    private final Counter recipeSearchesCounter;
    private final Timer recipeOperationTimer;

    public RecipeServiceImpl(RecipeRepository recipeRepository,
                             Counter recipesCreatedCounter,
                             Counter recipesDeletedCounter,
                             Counter recipeSearchesCounter,
                             Timer recipeOperationTimer) {
        this.recipeRepository = recipeRepository;
        this.recipesCreatedCounter = recipesCreatedCounter;
        this.recipesDeletedCounter = recipesDeletedCounter;
        this.recipeSearchesCounter = recipeSearchesCounter;
        this.recipeOperationTimer = recipeOperationTimer;
    }

    @Override
    @Transactional(readOnly = true)
    public List<RecipeResponse> getAllRecipes(Category category, String keyword) {
        return recipeOperationTimer.record(() -> {
            if (category != null || (keyword != null && !keyword.isBlank())) {
                recipeSearchesCounter.increment();
                String cleanKeyword = (keyword != null && !keyword.isBlank()) ? keyword.trim() : null;
                return recipeRepository.searchRecipes(category, cleanKeyword).stream()
                        .map(RecipeResponse::fromEntity)
                        .collect(Collectors.toList());
            }

            return recipeRepository.findAll().stream()
                    .map(RecipeResponse::fromEntity)
                    .collect(Collectors.toList());
        });
    }

    @Override
    @Transactional(readOnly = true)
    public RecipeResponse getRecipeById(Long id) {
        return recipeRepository.findById(id)
                .map(RecipeResponse::fromEntity)
                .orElseThrow(() -> new ResourceNotFoundException("Recipe not found with id: " + id));
    }

    @Override
    public RecipeResponse createRecipe(RecipeRequest request) {
        log.info("Creating new recipe: {}", request.getTitle());
        Recipe recipe = new Recipe();
        populateRecipeFromRequest(recipe, request);

        Recipe saved = recipeRepository.save(recipe);
        recipesCreatedCounter.increment();
        log.info("Recipe created successfully with id: {}", saved.getId());
        return RecipeResponse.fromEntity(saved);
    }

    @Override
    public RecipeResponse updateRecipe(Long id, RecipeRequest request) {
        log.info("Updating recipe id: {}", id);
        Recipe recipe = recipeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Recipe not found with id: " + id));

        populateRecipeFromRequest(recipe, request);
        Recipe updated = recipeRepository.save(recipe);
        log.info("Recipe id {} updated successfully", id);
        return RecipeResponse.fromEntity(updated);
    }

    @Override
    public void deleteRecipe(Long id) {
        log.info("Deleting recipe id: {}", id);
        if (!recipeRepository.existsById(id)) {
            throw new ResourceNotFoundException("Cannot delete. Recipe not found with id: " + id);
        }
        recipeRepository.deleteById(id);
        recipesDeletedCounter.increment();
        log.info("Recipe id {} deleted successfully", id);
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> getRecipeStats() {
        Map<String, Object> stats = new HashMap<>();
        long total = recipeRepository.count();
        stats.put("totalRecipes", total);

        Map<String, Long> categoryCounts = new HashMap<>();
        for (Category cat : Category.values()) {
            categoryCounts.put(cat.name(), recipeRepository.countByCategory(cat));
        }
        stats.put("byCategory", categoryCounts);
        return stats;
    }

    private void populateRecipeFromRequest(Recipe recipe, RecipeRequest request) {
        recipe.setTitle(request.getTitle());
        recipe.setDescription(request.getDescription());
        recipe.setCategory(request.getCategory());
        recipe.setIngredients(request.getIngredients());
        recipe.setInstructions(request.getInstructions());
        recipe.setPrepTimeMinutes(request.getPrepTimeMinutes());
        recipe.setCookTimeMinutes(request.getCookTimeMinutes());
        recipe.setServings(request.getServings());
        recipe.setDifficulty(request.getDifficulty() != null ? request.getDifficulty() : "Easy");
        recipe.setImageUrl(request.getImageUrl());
        recipe.setAuthor(request.getAuthor() != null ? request.getAuthor() : "Chef");
    }
}
