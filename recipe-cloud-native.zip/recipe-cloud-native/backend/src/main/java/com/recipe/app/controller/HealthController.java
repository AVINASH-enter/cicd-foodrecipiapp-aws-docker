package com.recipe.app.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;
import java.lang.management.ManagementFactory;
import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/status")
public class HealthController {

    private final DataSource dataSource;

    public HealthController(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @GetMapping
    public ResponseEntity<Map<String, Object>> getSystemStatus() {
        Map<String, Object> status = new LinkedHashMap<>();
        status.put("application", "Food Recipe Cloud-Native API");
        status.put("version", "1.0.0");
        status.put("timestamp", LocalDateTime.now().toString());
        status.put("uptimeSeconds", ManagementFactory.getRuntimeMXBean().getUptime() / 1000);

        boolean dbConnected = false;
        try (Connection conn = dataSource.getConnection()) {
            dbConnected = conn.isValid(2);
        } catch (Exception ignored) {}

        status.put("databaseStatus", dbConnected ? "UP" : "DOWN");
        status.put("framework", "Spring Boot 3.3.4 (Java 21)");
        status.put("monitoring", "Micrometer / Prometheus (/actuator/prometheus)");
        return ResponseEntity.ok(status);
    }
}
