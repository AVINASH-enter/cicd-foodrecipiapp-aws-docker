package com.recipe.app.config;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MetricsConfig {

    @Bean
    public Counter recipesCreatedCounter(MeterRegistry meterRegistry) {
        return Counter.builder("recipes_created_total")
                .description("Total number of recipes created")
                .tag("service", "recipe-api")
                .register(meterRegistry);
    }

    @Bean
    public Counter recipesDeletedCounter(MeterRegistry meterRegistry) {
        return Counter.builder("recipes_deleted_total")
                .description("Total number of recipes deleted")
                .tag("service", "recipe-api")
                .register(meterRegistry);
    }

    @Bean
    public Counter recipeSearchesCounter(MeterRegistry meterRegistry) {
        return Counter.builder("recipe_searches_total")
                .description("Total number of recipe search operations")
                .tag("service", "recipe-api")
                .register(meterRegistry);
    }

    @Bean
    public Timer recipeOperationTimer(MeterRegistry meterRegistry) {
        return Timer.builder("recipe_operations_duration_seconds")
                .description("Time taken to execute recipe operations")
                .publishPercentileHistogram()
                .register(meterRegistry);
    }
}
