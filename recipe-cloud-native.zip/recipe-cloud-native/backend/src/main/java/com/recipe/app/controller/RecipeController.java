package com.recipe.app.controller;

import com.recipe.app.dto.ApiResponse;
import com.recipe.app.dto.RecipeRequest;
import com.recipe.app.dto.RecipeResponse;
import com.recipe.app.model.Category;
import com.recipe.app.service.RecipeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/recipes")
public class RecipeController {

    private final RecipeService recipeService;

    public RecipeController(RecipeService recipeService) {
        this.recipeService = recipeService;
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<RecipeResponse>>> getAllRecipes(
            @RequestParam(required = false) Category category,
            @RequestParam(required = false) String keyword) {
        List<RecipeResponse> recipes = recipeService.getAllRecipes(category, keyword);
        return ResponseEntity.ok(ApiResponse.success("Recipes retrieved successfully", recipes));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<RecipeResponse>> getRecipeById(@PathVariable Long id) {
        RecipeResponse recipe = recipeService.getRecipeById(id);
        return ResponseEntity.ok(ApiResponse.success("Recipe retrieved successfully", recipe));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<RecipeResponse>> createRecipe(@Valid @RequestBody RecipeRequest request) {
        RecipeResponse created = recipeService.createRecipe(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Recipe created successfully", created));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<RecipeResponse>> updateRecipe(
            @PathVariable Long id,
            @Valid @RequestBody RecipeRequest request) {
        RecipeResponse updated = recipeService.updateRecipe(id, request);
        return ResponseEntity.ok(ApiResponse.success("Recipe updated successfully", updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteRecipe(@PathVariable Long id) {
        recipeService.deleteRecipe(id);
        return ResponseEntity.ok(ApiResponse.success("Recipe deleted successfully", null));
    }

    @GetMapping("/stats")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getRecipeStats() {
        Map<String, Object> stats = recipeService.getRecipeStats();
        return ResponseEntity.ok(ApiResponse.success("Recipe stats retrieved successfully", stats));
    }
}
