package com.recipe.app.dto;

import com.recipe.app.model.Category;
import com.recipe.app.model.Recipe;
import java.time.LocalDateTime;
import java.util.List;

public class RecipeResponse {
    private Long id;
    private String title;
    private String description;
    private Category category;
    private List<String> ingredients;
    private String instructions;
    private Integer prepTimeMinutes;
    private Integer cookTimeMinutes;
    private Integer totalTimeMinutes;
    private Integer servings;
    private String difficulty;
    private String imageUrl;
    private String author;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public RecipeResponse() {}

    public static RecipeResponse fromEntity(Recipe recipe) {
        RecipeResponse res = new RecipeResponse();
        res.setId(recipe.getId());
        res.setTitle(recipe.getTitle());
        res.setDescription(recipe.getDescription());
        res.setCategory(recipe.getCategory());
        res.setIngredients(recipe.getIngredients());
        res.setInstructions(recipe.getInstructions());
        res.setPrepTimeMinutes(recipe.getPrepTimeMinutes());
        res.setCookTimeMinutes(recipe.getCookTimeMinutes());
        int prep = recipe.getPrepTimeMinutes() != null ? recipe.getPrepTimeMinutes() : 0;
        int cook = recipe.getCookTimeMinutes() != null ? recipe.getCookTimeMinutes() : 0;
        res.setTotalTimeMinutes(prep + cook);
        res.setServings(recipe.getServings());
        res.setDifficulty(recipe.getDifficulty());
        res.setImageUrl(recipe.getImageUrl());
        res.setAuthor(recipe.getAuthor());
        res.setCreatedAt(recipe.getCreatedAt());
        res.setUpdatedAt(recipe.getUpdatedAt());
        return res;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }

    public List<String> getIngredients() { return ingredients; }
    public void setIngredients(List<String> ingredients) { this.ingredients = ingredients; }

    public String getInstructions() { return instructions; }
    public void setInstructions(String instructions) { this.instructions = instructions; }

    public Integer getPrepTimeMinutes() { return prepTimeMinutes; }
    public void setPrepTimeMinutes(Integer prepTimeMinutes) { this.prepTimeMinutes = prepTimeMinutes; }

    public Integer getCookTimeMinutes() { return cookTimeMinutes; }
    public void setCookTimeMinutes(Integer cookTimeMinutes) { this.cookTimeMinutes = cookTimeMinutes; }

    public Integer getTotalTimeMinutes() { return totalTimeMinutes; }
    public void setTotalTimeMinutes(Integer totalTimeMinutes) { this.totalTimeMinutes = totalTimeMinutes; }

    public Integer getServings() { return servings; }
    public void setServings(Integer servings) { this.servings = servings; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
