package com.recipe.app;

import com.recipe.app.dto.RecipeRequest;
import com.recipe.app.dto.RecipeResponse;
import com.recipe.app.exception.ResourceNotFoundException;
import com.recipe.app.model.Category;
import com.recipe.app.model.Recipe;
import com.recipe.app.repository.RecipeRepository;
import com.recipe.app.service.RecipeServiceImpl;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Timer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RecipeServiceTest {

    @Mock
    private RecipeRepository recipeRepository;

    @Mock
    private Counter recipesCreatedCounter;

    @Mock
    private Counter recipesDeletedCounter;

    @Mock
    private Counter recipeSearchesCounter;

    @Mock
    private Timer recipeOperationTimer;

    private RecipeServiceImpl recipeService;

    private Recipe sampleRecipe;

    @BeforeEach
    void setUp() {
        recipeService = new RecipeServiceImpl(
                recipeRepository,
                recipesCreatedCounter,
                recipesDeletedCounter,
                recipeSearchesCounter,
                recipeOperationTimer
        );

        sampleRecipe = new Recipe(
                "Test Recipe",
                "Delicious test recipe",
                Category.DINNER,
                List.of("Ingredient 1", "Ingredient 2"),
                "Step 1. Cook it.",
                10, 20, 2, "Easy",
                "https://example.com/test.jpg",
                "Tester"
        );
        sampleRecipe.setId(1L);
    }

    @Test
    @DisplayName("Should return all recipes when no filters applied")
    void testGetAllRecipes() {
        when(recipeOperationTimer.record(any(Supplier.class))).thenAnswer(invocation -> {
            Supplier<?> supplier = invocation.getArgument(0);
            return supplier.get();
        });
        when(recipeRepository.findAll()).thenReturn(List.of(sampleRecipe));

        List<RecipeResponse> results = recipeService.getAllRecipes(null, null);

        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("Test Recipe", results.get(0).getTitle());
        verify(recipeRepository, times(1)).findAll();
    }

    @Test
    @DisplayName("Should find recipe by valid ID")
    void testGetRecipeById_Success() {
        when(recipeRepository.findById(1L)).thenReturn(Optional.of(sampleRecipe));

        RecipeResponse response = recipeService.getRecipeById(1L);

        assertNotNull(response);
        assertEquals(1L, response.getId());
        assertEquals("Test Recipe", response.getTitle());
    }

    @Test
    @DisplayName("Should throw ResourceNotFoundException when recipe ID does not exist")
    void testGetRecipeById_NotFound() {
        when(recipeRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> recipeService.getRecipeById(99L));
    }

    @Test
    @DisplayName("Should create recipe and increment Prometheus metric counter")
    void testCreateRecipe() {
        RecipeRequest request = new RecipeRequest();
        request.setTitle("New Recipe");
        request.setCategory(Category.LUNCH);
        request.setIngredients(List.of("Bread", "Cheese"));
        request.setInstructions("Grill it");

        when(recipeRepository.save(any(Recipe.class))).thenAnswer(inv -> {
            Recipe r = inv.getArgument(0);
            r.setId(2L);
            return r;
        });

        RecipeResponse created = recipeService.createRecipe(request);

        assertNotNull(created);
        assertEquals(2L, created.getId());
        assertEquals("New Recipe", created.getTitle());
        verify(recipesCreatedCounter, times(1)).increment();
    }

    @Test
    @DisplayName("Should delete recipe and increment Prometheus metric counter")
    void testDeleteRecipe_Success() {
        when(recipeRepository.existsById(1L)).thenReturn(true);
        doNothing().when(recipeRepository).deleteById(1L);

        recipeService.deleteRecipe(1L);

        verify(recipeRepository, times(1)).deleteById(1L);
        verify(recipesDeletedCounter, times(1)).increment();
    }
}
