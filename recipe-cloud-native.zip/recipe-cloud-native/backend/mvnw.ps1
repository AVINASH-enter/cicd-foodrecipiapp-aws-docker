# Maven Wrapper for PowerShell
$ErrorActionPreference = "Stop"
$basedir = $PSScriptRoot

if (-not (Test-Path "$basedir\.mvn\wrapper\maven-wrapper.jar")) {
    Write-Host "Downloading Maven wrapper..."
    Invoke-WebRequest -Uri "https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.3.2/maven-wrapper-3.3.2.jar" -OutFile "$basedir\.mvn\wrapper\maven-wrapper.jar"
}

$javaCmd = "java"
if ($env:JAVA_HOME) {
    $javaCmd = "$env:JAVA_HOME\bin\java.exe"
}

& $javaCmd "-Dmaven.multiModuleProjectDirectory=$basedir" -cp "$basedir\.mvn\wrapper\maven-wrapper.jar" org.apache.maven.wrapper.MavenWrapperMain $args
