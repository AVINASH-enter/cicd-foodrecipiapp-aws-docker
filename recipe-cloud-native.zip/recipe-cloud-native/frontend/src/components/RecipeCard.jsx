import React from 'react';
import { Clock, Users, Edit3, Trash2, Eye } from 'lucide-react';

export default function RecipeCard({ recipe, onView, onEdit, onDelete }) {
  const getDifficultyColor = (difficulty) => {
    switch (difficulty?.toLowerCase()) {
      case 'easy':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'medium':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'hard':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const defaultImage = "https://images.unsplash.com/photo-1495521821757-a1efb6729352?auto=format&fit=crop&w=800&q=80";

  return (
    <div className="group bg-white rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden">
      {/* Image Container */}
      <div className="relative h-48 w-full overflow-hidden bg-slate-100">
        <img
          src={recipe.imageUrl || defaultImage}
          alt={recipe.title}
          onError={(e) => { e.target.src = defaultImage; }}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60"></div>

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex items-center space-x-2">
          <span className="px-2.5 py-1 text-xs font-semibold uppercase tracking-wider rounded-lg bg-black/50 backdrop-blur-md text-white border border-white/20">
            {recipe.category?.replace('_', ' ')}
          </span>
        </div>

        <div className="absolute top-3 right-3">
          <span className={`px-2.5 py-0.5 text-xs font-medium rounded-full border backdrop-blur-md ${getDifficultyColor(recipe.difficulty)}`}>
            {recipe.difficulty || 'Easy'}
          </span>
        </div>

        {/* Bottom Time / Servings pill over image */}
        <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-white text-xs font-medium drop-shadow">
          <div className="flex items-center space-x-1">
            <Clock className="w-3.5 h-3.5" />
            <span>{recipe.totalTimeMinutes || (recipe.prepTimeMinutes + recipe.cookTimeMinutes) || 20} mins</span>
          </div>
          <div className="flex items-center space-x-1">
            <Users className="w-3.5 h-3.5" />
            <span>{recipe.servings || 2} servings</span>
          </div>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <h3 
            onClick={() => onView(recipe)}
            className="text-lg font-bold text-slate-900 group-hover:text-brand-600 transition-colors cursor-pointer line-clamp-1"
            title={recipe.title}
          >
            {recipe.title}
          </h3>

          <p className="mt-2 text-sm text-slate-600 line-clamp-2 leading-relaxed">
            {recipe.description || 'Delicious home-cooked meal prepared with fresh ingredients.'}
          </p>

          <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
            <span>By <span className="font-medium text-slate-700">{recipe.author || 'Chef'}</span></span>
            <span>{recipe.ingredients?.length || 0} ingredients</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
          <button
            onClick={() => onView(recipe)}
            className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-semibold text-brand-600 bg-brand-50 hover:bg-brand-100 rounded-lg transition"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>View Recipe</span>
          </button>

          <div className="flex items-center space-x-1">
            <button
              onClick={() => onEdit(recipe)}
              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition"
              title="Edit Recipe"
            >
              <Edit3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(recipe.id)}
              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
              title="Delete Recipe"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
