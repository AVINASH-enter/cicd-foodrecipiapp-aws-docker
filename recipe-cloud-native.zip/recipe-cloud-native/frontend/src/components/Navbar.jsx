import React from 'react';
import { UtensilsCrossed, Plus, Activity, BarChart3, RefreshCw } from 'lucide-react';

export default function Navbar({ onOpenNewModal, onOpenMetrics, backendStatus, onRefresh }) {
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={onRefresh}>
            <div className="bg-gradient-to-tr from-brand-600 to-amber-500 p-2.5 rounded-xl shadow-md text-white shadow-brand-500/20">
              <UtensilsCrossed className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent">
                GourmetCloud
              </span>
              <span className="hidden sm:inline-block ml-2 px-2 py-0.5 text-xs font-semibold bg-brand-100 text-brand-700 rounded-full">
                K8s Native
              </span>
            </div>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center space-x-3">
            {/* Live Backend Status Badge */}
            <div 
              onClick={onOpenMetrics}
              className={`hidden md:flex items-center space-x-2 px-3 py-1.5 rounded-full text-xs font-medium cursor-pointer transition border ${
                backendStatus?.online
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                  : 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100'
              }`}
              title="Click to view Cloud-Native Monitoring info"
            >
              <span className="relative flex h-2 w-2">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  backendStatus?.online ? 'bg-emerald-400' : 'bg-rose-400'
                }`}></span>
                <span className={`relative inline-flex rounded-full h-2 w-2 ${
                  backendStatus?.online ? 'bg-emerald-500' : 'bg-rose-500'
                }`}></span>
              </span>
              <span>{backendStatus?.online ? 'Spring Boot: UP' : 'Backend: Disconnected'}</span>
            </div>

            {/* Monitoring Button */}
            <button
              onClick={onOpenMetrics}
              className="flex items-center space-x-1.5 px-3 py-2 text-sm font-medium text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
              title="Prometheus & Grafana Telemetry"
            >
              <BarChart3 className="w-4 h-4 text-slate-600" />
              <span className="hidden sm:inline">Telemetry</span>
            </button>

            {/* Refresh */}
            <button
              onClick={onRefresh}
              className="p-2 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
              title="Refresh Recipes"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {/* Add Recipe Button */}
            <button
              onClick={onOpenNewModal}
              className="flex items-center space-x-1.5 px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-brand-600 to-amber-600 hover:from-brand-700 hover:to-amber-700 rounded-lg shadow-sm shadow-brand-600/30 transition transform active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>Create Recipe</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
