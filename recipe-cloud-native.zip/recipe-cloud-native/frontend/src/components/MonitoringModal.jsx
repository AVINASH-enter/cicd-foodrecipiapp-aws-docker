import React from 'react';
import { X, Activity, Server, Database, BarChart2, ShieldCheck, Cpu } from 'lucide-react';

export default function MonitoringModal({ isOpen, onClose, backendStatus, stats }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-brand-500/20 text-brand-400 rounded-xl border border-brand-500/30">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Cloud-Native Telemetry & Monitoring</h2>
              <p className="text-xs text-slate-400">Prometheus, Grafana, Spring Actuator & Kubernetes</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {/* Status summary grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-start space-x-3">
              <Server className="w-5 h-5 text-brand-600 mt-1" />
              <div>
                <p className="text-xs text-slate-500 font-semibold uppercase">API Pod Status</p>
                <p className="text-base font-bold text-slate-800">
                  {backendStatus?.online ? 'Healthy (200 OK)' : 'Offline / Standby'}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">Uptime: {backendStatus?.uptimeSeconds || 0}s</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-start space-x-3">
              <Database className="w-5 h-5 text-emerald-600 mt-1" />
              <div>
                <p className="text-xs text-slate-500 font-semibold uppercase">MySQL Database</p>
                <p className="text-base font-bold text-slate-800">
                  {backendStatus?.databaseStatus === 'UP' ? 'Connected (Stateful)' : 'Connecting...'}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">HikariCP Pool: Active</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-start space-x-3">
              <BarChart2 className="w-5 h-5 text-amber-600 mt-1" />
              <div>
                <p className="text-xs text-slate-500 font-semibold uppercase">Total Recipes</p>
                <p className="text-base font-bold text-slate-800">{stats?.totalRecipes || 0}</p>
                <p className="text-xs text-slate-400 mt-0.5">Persistent across restarts</p>
              </div>
            </div>
          </div>

          {/* Prometheus Metrics Section */}
          <div className="border border-slate-200 rounded-2xl p-5 bg-white">
            <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2 mb-3">
              <Cpu className="w-4 h-4 text-brand-600" />
              <span>Prometheus Scrape Configuration</span>
            </h3>
            <p className="text-xs text-slate-600 mb-3">
              Spring Boot exposes Micrometer metrics at <code className="px-1.5 py-0.5 bg-slate-100 text-brand-700 rounded font-mono text-xs">/actuator/prometheus</code>, which is automatically scraped by the Prometheus Kubernetes DaemonSet every 15s.
            </p>

            <div className="space-y-2 font-mono text-xs bg-slate-900 text-emerald-400 p-4 rounded-xl overflow-x-auto">
              <div># Custom App Business Metrics</div>
              <div className="text-slate-300">recipes_created_total&#123;service="recipe-api"&#125;</div>
              <div className="text-slate-300">recipes_deleted_total&#123;service="recipe-api"&#125;</div>
              <div className="text-slate-300">recipe_searches_total&#123;service="recipe-api"&#125;</div>
              <div className="text-slate-300">recipe_operations_duration_seconds&#123;quantile="0.99"&#125;</div>
              <div className="pt-2"># JVM & Cloud Infrastructure Telemetry</div>
              <div className="text-slate-300">jvm_memory_used_bytes&#123;area="heap"&#125;</div>
              <div className="text-slate-300">hikaricp_connections_active&#123;pool="HikariPool-1"&#125;</div>
              <div className="text-slate-300">http_server_requests_seconds_count&#123;status="200"&#125;</div>
            </div>
          </div>

          {/* Quick Links & Kubernetes Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl border border-slate-200">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Kubernetes Architecture</h4>
              <ul className="text-xs text-slate-600 space-y-1.5">
                <li>• <strong>Namespace:</strong> <span className="font-mono">recipe-app</span></li>
                <li>• <strong>Frontend:</strong> React 18 + NGINX (ClusterIP & Ingress)</li>
                <li>• <strong>Backend:</strong> Spring Boot 3 Java 21 (2 Replicas, HPA enabled)</li>
                <li>• <strong>Database:</strong> MySQL 8.0 (Stateful PVC & Headless Service)</li>
                <li>• <strong>Monitoring:</strong> Prometheus & Grafana Service</li>
              </ul>
            </div>

            <div className="p-4 rounded-2xl border border-slate-200">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Local & Cloud Ports</h4>
              <ul className="text-xs text-slate-600 space-y-1.5">
                <li>• <strong>Frontend UI:</strong> <span className="font-mono">http://localhost:3000</span></li>
                <li>• <strong>REST API:</strong> <span className="font-mono">http://localhost:8080/api/recipes</span></li>
                <li>• <strong>Actuator Metrics:</strong> <span className="font-mono">/actuator/prometheus</span></li>
                <li>• <strong>Prometheus Server:</strong> <span className="font-mono">http://localhost:9090</span></li>
                <li>• <strong>Grafana Dashboard:</strong> <span className="font-mono">http://localhost:3001</span></li>
              </ul>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center space-x-1.5 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>Kubernetes Readiness & Liveness Probes: Active</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-200 rounded-xl transition"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}
