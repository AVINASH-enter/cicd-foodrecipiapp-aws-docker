import React, { useState } from 'react';
import { X, Clock, Users, ChefHat, CheckCircle2, Circle, Edit3 } from 'lucide-react';

export default function RecipeDetailModal({ recipe, onClose, onEdit }) {
  const [checkedIngredients, setCheckedIngredients] = useState({});

  if (!recipe) return null;

  const toggleIngredient = (idx) => {
    setCheckedIngredients((prev) => ({
      ...prev,
      [idx]: !prev[idx],
    }));
  };

  const defaultImage = "https://images.unsplash.com/photo-1495521821757-a1efb6729352?auto=format&fit=crop&w=800&q=80";

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Hero Header with Image */}
        <div className="relative h-64 sm:h-72 w-full bg-slate-900">
          <img
            src={recipe.imageUrl || defaultImage}
            alt={recipe.title}
            onError={(e) => { e.target.src = defaultImage; }}
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent"></div>

          {/* Close & Edit buttons */}
          <div className="absolute top-4 right-4 flex items-center space-x-2">
            <button
              onClick={() => onEdit(recipe)}
              className="p-2 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-full text-white transition"
              title="Edit Recipe"
            >
              <Edit3 className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-full text-white transition"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Title and Badges */}
          <div className="absolute bottom-6 left-6 right-6 text-white">
            <div className="flex items-center space-x-2 mb-2">
              <span className="px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wider rounded-md bg-brand-500 text-white">
                {recipe.category?.replace('_', ' ')}
              </span>
              <span className="px-2.5 py-0.5 text-xs font-medium rounded-md bg-white/20 backdrop-blur-md text-white border border-white/20">
                Difficulty: {recipe.difficulty || 'Easy'}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {recipe.title}
            </h2>
            <p className="text-sm text-slate-300 mt-1">
              Curated by <span className="font-medium text-white">{recipe.author || 'Chef'}</span>
            </p>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 max-h-[70vh] overflow-y-auto">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 text-center mb-6">
            <div>
              <p className="text-xs text-slate-500 uppercase font-semibold">Prep Time</p>
              <p className="text-base sm:text-lg font-bold text-slate-800">{recipe.prepTimeMinutes || 0} min</p>
            </div>
            <div className="border-x border-slate-200">
              <p className="text-xs text-slate-500 uppercase font-semibold">Cook Time</p>
              <p className="text-base sm:text-lg font-bold text-slate-800">{recipe.cookTimeMinutes || 0} min</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 uppercase font-semibold">Servings</p>
              <p className="text-base sm:text-lg font-bold text-slate-800">{recipe.servings || 2}</p>
            </div>
          </div>

          {/* Description */}
          {recipe.description && (
            <div className="mb-6">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">About this dish</h3>
              <p className="text-slate-700 leading-relaxed">{recipe.description}</p>
            </div>
          )}

          {/* 2-column layout: Ingredients & Instructions */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
            
            {/* Ingredients (2 cols) */}
            <div className="md:col-span-2">
              <h3 className="text-lg font-bold text-slate-900 mb-3 flex items-center space-x-2">
                <ChefHat className="w-5 h-5 text-brand-600" />
                <span>Ingredients</span>
              </h3>
              <p className="text-xs text-slate-500 mb-3">Check off ingredients as you prepare them:</p>
              
              <ul className="space-y-2">
                {recipe.ingredients?.map((ing, idx) => {
                  const isChecked = checkedIngredients[idx];
                  return (
                    <li
                      key={idx}
                      onClick={() => toggleIngredient(idx)}
                      className={`flex items-start space-x-2.5 p-2 rounded-xl cursor-pointer transition text-sm ${
                        isChecked ? 'bg-slate-100 text-slate-400 line-through' : 'hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      {isChecked ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                      )}
                      <span>{ing}</span>
                    </li>
                  );
                })}
              </ul>
            </div>

            {/* Instructions (3 cols) */}
            <div className="md:col-span-3">
              <h3 className="text-lg font-bold text-slate-900 mb-3">
                Cooking Instructions
              </h3>
              <div className="prose prose-slate max-w-none text-sm text-slate-700 space-y-3 leading-relaxed whitespace-pre-line">
                {recipe.instructions}
              </div>
            </div>

          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end space-x-3">
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-200 rounded-xl transition"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}
