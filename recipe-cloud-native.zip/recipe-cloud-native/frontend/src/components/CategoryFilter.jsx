import React from 'react';

const CATEGORIES = [
  { id: 'ALL', label: 'All Recipes', icon: '🍽️' },
  { id: 'BREAKFAST', label: 'Breakfast', icon: '🥞' },
  { id: 'LUNCH', label: 'Lunch', icon: '🥗' },
  { id: 'DINNER', label: 'Dinner', icon: '🍲' },
  { id: 'DESSERT', label: 'Dessert', icon: '🍰' },
  { id: 'VEGAN', label: 'Vegan', icon: '🥑' },
  { id: 'QUICK_EASY', label: 'Quick & Easy', icon: '⚡' },
];

export default function CategoryFilter({ activeCategory, onSelectCategory }) {
  return (
    <div className="flex items-center space-x-2 overflow-x-auto py-2 scrollbar-none">
      {CATEGORIES.map((cat) => {
        const isActive = activeCategory === cat.id;
        return (
          <button
            key={cat.id}
            onClick={() => onSelectCategory(cat.id)}
            className={`whitespace-nowrap px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 flex items-center space-x-2 ${
              isActive
                ? 'bg-slate-900 text-white shadow-md shadow-slate-900/10'
                : 'bg-white text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-slate-200/80'
            }`}
          >
            <span>{cat.icon}</span>
            <span>{cat.label}</span>
          </button>
        );
      })}
    </div>
  );
}
