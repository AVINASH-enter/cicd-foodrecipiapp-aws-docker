const API_BASE_URL = '/api';

export const RecipeApi = {
  async getAll(category = null, keyword = '') {
    const params = new URLSearchParams();
    if (category && category !== 'ALL') params.append('category', category);
    if (keyword && keyword.trim() !== '') params.append('keyword', keyword.trim());

    const queryString = params.toString() ? `?${params.toString()}` : '';
    const res = await fetch(`${API_BASE_URL}/recipes${queryString}`);
    if (!res.ok) {
      throw new Error(`Failed to fetch recipes: ${res.statusText}`);
    }
    const json = await res.json();
    return json.data || [];
  },

  async getById(id) {
    const res = await fetch(`${API_BASE_URL}/recipes/${id}`);
    if (!res.ok) throw new Error(`Recipe with id ${id} not found`);
    const json = await res.json();
    return json.data;
  },

  async create(recipe) {
    const res = await fetch(`${API_BASE_URL}/recipes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(recipe),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: res.statusText }));
      throw new Error(err.message || 'Failed to create recipe');
    }
    const json = await res.json();
    return json.data;
  },

  async update(id, recipe) {
    const res = await fetch(`${API_BASE_URL}/recipes/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(recipe),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: res.statusText }));
      throw new Error(err.message || 'Failed to update recipe');
    }
    const json = await res.json();
    return json.data;
  },

  async delete(id) {
    const res = await fetch(`${API_BASE_URL}/recipes/${id}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error('Failed to delete recipe');
    return true;
  },

  async getStats() {
    const res = await fetch(`${API_BASE_URL}/recipes/stats`);
    if (!res.ok) throw new Error('Failed to fetch statistics');
    const json = await res.json();
    return json.data;
  },

  async checkStatus() {
    try {
      const res = await fetch(`${API_BASE_URL}/status`, { signal: AbortSignal.timeout(3000) });
      if (!res.ok) return { online: false, error: res.statusText };
      const data = await res.json();
      return { online: true, ...data };
    } catch (err) {
      return { online: false, error: err.message };
    }
  }
};
