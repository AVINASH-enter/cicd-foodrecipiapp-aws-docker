import React, { useState, useEffect, useCallback } from 'react';
import Navbar from './components/Navbar';
import CategoryFilter from './components/CategoryFilter';
import RecipeCard from './components/RecipeCard';
import RecipeDetailModal from './components/RecipeDetailModal';
import RecipeFormModal from './components/RecipeFormModal';
import MonitoringModal from './components/MonitoringModal';
import { RecipeApi } from './services/api';
import { Search, Sparkles, ChefHat, AlertCircle, RefreshCw } from 'lucide-react';

const FALLBACK_RECIPES = [
  {
    id: 1,
    title: "Mediterranean Grilled Salmon",
    description: "Fresh wild salmon fillets marinated in lemon, garlic, olive oil, and aromatic fresh herbs, grilled to flaky perfection.",
    category: "DINNER",
    ingredients: [
      "4 wild-caught salmon fillets",
      "3 tbsp extra virgin olive oil",
      "2 cloves minced garlic",
      "Juice and zest of 1 fresh lemon",
      "1 tsp dried oregano",
      "1/2 tsp smoked paprika"
    ],
    instructions: "1. Whisk marinade ingredients.\n2. Coat salmon and let rest for 15 minutes.\n3. Grill on medium-high for 4-5 minutes per side.",
    prepTimeMinutes: 15,
    cookTimeMinutes: 10,
    totalTimeMinutes: 25,
    servings: 4,
    difficulty: "Easy",
    imageUrl: "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=800&q=80",
    author: "Chef Sophia Vance"
  },
  {
    id: 2,
    title: "Avocado Sourdough Toast with Poached Egg",
    description: "Artisanal toasted sourdough bread topped with creamy mashed avocado, chili flakes, microgreens, and a silky soft-poached farm egg.",
    category: "BREAKFAST",
    ingredients: [
      "2 thick slices artisanal sourdough bread",
      "1 ripe Haas avocado",
      "2 organic free-range eggs",
      "1 tbsp white vinegar",
      "Red pepper flakes and flaky sea salt"
    ],
    instructions: "1. Toast sourdough slices.\n2. Mash avocado with lemon and salt.\n3. Poach eggs in simmering water for 3 mins.\n4. Assemble toast with mashed avocado, egg, and chili flakes.",
    prepTimeMinutes: 10,
    cookTimeMinutes: 5,
    totalTimeMinutes: 15,
    servings: 2,
    difficulty: "Easy",
    imageUrl: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=800&q=80",
    author: "Chef Marco Rossi"
  },
  {
    id: 3,
    title: "Creamy Tuscan Garlic Chicken",
    description: "Tender golden chicken breasts simmered in a rich garlic cream sauce with sun-dried tomatoes, baby spinach, and aged parmesan.",
    category: "DINNER",
    ingredients: [
      "2 large chicken breasts",
      "4 cloves minced garlic",
      "1 cup heavy cream",
      "1/2 cup sun-dried tomatoes",
      "2 cups baby spinach",
      "1/2 cup grated Parmesan"
    ],
    instructions: "1. Sear chicken cutlets 5 mins per side.\n2. Sauté garlic, add cream and broth.\n3. Wilt spinach and stir in Parmesan.\n4. Return chicken to skillet.",
    prepTimeMinutes: 15,
    cookTimeMinutes: 20,
    totalTimeMinutes: 35,
    servings: 4,
    difficulty: "Medium",
    imageUrl: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&w=800&q=80",
    author: "Chef Elena Rostova"
  }
];

export default function App() {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const [editingRecipe, setEditingRecipe] = useState(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isMonitoringOpen, setIsMonitoringOpen] = useState(false);
  
  const [backendStatus, setBackendStatus] = useState({ online: false });
  const [stats, setStats] = useState(null);
  const [usingFallback, setUsingFallback] = useState(false);

  // Check backend health
  const checkHealth = useCallback(async () => {
    const status = await RecipeApi.checkStatus();
    setBackendStatus(status);
    if (status.online) {
      try {
        const statsData = await RecipeApi.getStats();
        setStats(statsData);
      } catch (e) {}
    }
  }, []);

  // Fetch recipes
  const loadRecipes = useCallback(async () => {
    setLoading(true);
    try {
      const data = await RecipeApi.getAll(activeCategory, searchQuery);
      setRecipes(data);
      setUsingFallback(false);
    } catch (err) {
      console.warn('Backend unavailable, using fallback mock data:', err.message);
      // Filter fallback recipes locally for a seamless demo
      let filtered = FALLBACK_RECIPES;
      if (activeCategory !== 'ALL') {
        filtered = filtered.filter(r => r.category === activeCategory);
      }
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        filtered = filtered.filter(r => r.title.toLowerCase().includes(q) || r.description?.toLowerCase().includes(q));
      }
      setRecipes(filtered);
      setUsingFallback(true);
    } finally {
      setLoading(false);
    }
  }, [activeCategory, searchQuery]);

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, 10000);
    return () => clearInterval(interval);
  }, [checkHealth]);

  useEffect(() => {
    loadRecipes();
  }, [loadRecipes]);

  // Create or Update
  const handleSaveRecipe = async (payload, id) => {
    if (id) {
      if (!usingFallback) {
        await RecipeApi.update(id, payload);
      } else {
        setRecipes(prev => prev.map(r => r.id === id ? { ...payload, id } : r));
      }
    } else {
      if (!usingFallback) {
        await RecipeApi.create(payload);
      } else {
        const newR = { ...payload, id: Date.now(), totalTimeMinutes: payload.prepTimeMinutes + payload.cookTimeMinutes };
        setRecipes(prev => [newR, ...prev]);
      }
    }
    loadRecipes();
    checkHealth();
  };

  // Delete
  const handleDeleteRecipe = async (id) => {
    if (window.confirm('Are you sure you want to delete this recipe?')) {
      try {
        if (!usingFallback) {
          await RecipeApi.delete(id);
        } else {
          setRecipes(prev => prev.filter(r => r.id !== id));
        }
        loadRecipes();
        checkHealth();
      } catch (err) {
        alert('Failed to delete: ' + err.message);
      }
    }
  };

  const handleEdit = (recipe) => {
    setEditingRecipe(recipe);
    setSelectedRecipe(null);
    setIsFormOpen(true);
  };

  const handleCreateNew = () => {
    setEditingRecipe(null);
    setIsFormOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      {/* Top Navigation */}
      <Navbar
        onOpenNewModal={handleCreateNew}
        onOpenMetrics={() => setIsMonitoringOpen(true)}
        backendStatus={backendStatus}
        onRefresh={() => { loadRecipes(); checkHealth(); }}
      />

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Banner if in fallback mode */}
        {usingFallback && (
          <div className="mb-6 p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between text-amber-900">
            <div className="flex items-center space-x-3">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
              <div className="text-xs sm:text-sm">
                <span className="font-semibold">Local Fallback Mode Active:</span> Backend container is offline or starting up. Showing cached demo recipes.
              </div>
            </div>
            <button
              onClick={() => { checkHealth(); loadRecipes(); }}
              className="text-xs font-semibold px-3 py-1.5 bg-amber-200/80 hover:bg-amber-200 rounded-lg transition"
            >
              Retry Connection
            </button>
          </div>
        )}

        {/* Hero & Search Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
          <div>
            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-brand-50 border border-brand-200/60 text-brand-700 text-xs font-semibold mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Cloud-Native Gourmet Kitchen</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Culinary Recipes & Insights
            </h1>
            <p className="mt-2 text-sm text-slate-600 max-w-xl">
              Explore gourmet dishes, monitor container health, and orchestrate recipes with a cloud-native React, Spring Boot, MySQL & Kubernetes stack.
            </p>
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search recipes, ingredients..."
              className="w-full pl-10 pr-4 py-2.5 bg-white rounded-2xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 shadow-sm transition"
            />
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="mb-8">
          <CategoryFilter
            activeCategory={activeCategory}
            onSelectCategory={setActiveCategory}
          />
        </div>

        {/* Recipes Grid */}
        {loading ? (
          <div className="py-20 flex flex-col items-center justify-center text-slate-400">
            <RefreshCw className="w-8 h-8 animate-spin text-brand-500 mb-3" />
            <p className="text-sm">Fetching delicious recipes...</p>
          </div>
        ) : recipes.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {recipes.map((recipe) => (
              <RecipeCard
                key={recipe.id}
                recipe={recipe}
                onView={setSelectedRecipe}
                onEdit={handleEdit}
                onDelete={handleDeleteRecipe}
              />
            ))}
          </div>
        ) : (
          <div className="py-16 text-center bg-white rounded-3xl border border-slate-200 p-8 max-w-md mx-auto">
            <ChefHat className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-slate-800">No recipes found</h3>
            <p className="text-sm text-slate-500 mt-1 mb-6">
              Try adjusting your category or search query, or create a brand new recipe!
            </p>
            <button
              onClick={handleCreateNew}
              className="px-5 py-2.5 bg-brand-600 text-white font-semibold text-sm rounded-xl hover:bg-brand-700 transition"
            >
              Add First Recipe
            </button>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="mt-12 bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500">
        <p>Cloud-Native Food Recipe Stack • React 18 • Spring Boot 3.3.4 (Java 21) • MySQL 8 • Kubernetes • Prometheus & Grafana</p>
      </footer>

      {/* Modals */}
      <RecipeDetailModal
        recipe={selectedRecipe}
        onClose={() => setSelectedRecipe(null)}
        onEdit={handleEdit}
      />

      <RecipeFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSave={handleSaveRecipe}
        editingRecipe={editingRecipe}
      />

      <MonitoringModal
        isOpen={isMonitoringOpen}
        onClose={() => setIsMonitoringOpen(false)}
        backendStatus={backendStatus}
        stats={stats}
      />
    </div>
  );
}
