# GourmetCloud - Windows Deployment Script (PowerShell)
param (
    [string]$Mode = "compose"
)

Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "  Deploying Cloud-Native Food Recipe Stack ($Mode)     " -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan

if ($Mode -eq "compose") {
    Write-Host "`nBuilding and starting containers using Docker Compose..." -ForegroundColor Yellow
    docker compose down --remove-orphans
    docker compose build --parallel
    docker compose up -d

    Write-Host "`nWaiting for services to become healthy..." -ForegroundColor Yellow
    Start-Sleep -Seconds 15

    Write-Host "`nAll containers started!" -ForegroundColor Green
    Write-Host "------------------------------------------------------"
    Write-Host "  Frontend Web UI:      http://localhost:3000" -ForegroundColor Cyan
    Write-Host "  Backend REST API:     http://localhost:8080/api/recipes" -ForegroundColor Cyan
    Write-Host "  Prometheus Metrics:   http://localhost:8080/actuator/prometheus" -ForegroundColor Cyan
    Write-Host "  Prometheus Server:    http://localhost:9090" -ForegroundColor Cyan
    Write-Host "  Grafana Dashboard:    http://localhost:3001 (admin / admin)" -ForegroundColor Cyan
    Write-Host "------------------------------------------------------"
} elseif ($Mode -eq "k8s") {
    Write-Host "`nApplying Kubernetes manifests..." -ForegroundColor Yellow
    kubectl apply -k k8s/
    Write-Host "`nManifests applied. Check pods using: kubectl get pods -n recipe-app" -ForegroundColor Green
} else {
    Write-Host "Invalid mode. Choose 'compose' or 'k8s'." -ForegroundColor Red
}
