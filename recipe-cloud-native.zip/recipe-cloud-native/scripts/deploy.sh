#!/usr/bin/env bash
# ==============================================================================
# GourmetCloud - Deployment Automation Script
# Usage:
#   ./scripts/deploy.sh compose   (Deploys stack via Docker Compose)
#   ./scripts/deploy.sh k8s       (Deploys stack to Kubernetes cluster)
# ==============================================================================

set -euo pipefail

MODE="${1:-compose}"
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}======================================================${NC}"
echo -e "${BLUE}  Deploying Cloud-Native Food Recipe Stack (${MODE})    ${NC}"
echo -e "${BLUE}======================================================${NC}"

if [ "$MODE" == "compose" ]; then
    echo -e "\n${YELLOW}Building and starting containers using Docker Compose...${NC}"
    docker compose down --remove-orphans || true
    docker compose build --parallel
    docker compose up -d

    echo -e "\n${YELLOW}Waiting for services to become healthy...${NC}"
    echo "• Checking MySQL database health..."
    until docker compose exec -T mysql mysqladmin ping -h localhost -u recipe_user -precipe_password --silent 2>/dev/null; do
        sleep 2
        printf "."
    done
    echo -e " ${GREEN}[OK]${NC}"

    echo "• Checking Spring Boot backend health..."
    until docker compose exec -T backend wget -q --spider http://localhost:8080/actuator/health/liveness 2>/dev/null; do
        sleep 3
        printf "."
    done
    echo -e " ${GREEN}[OK]${NC}"

    echo -e "\n${GREEN}✓ All services are up and healthy!${NC}"
    echo -e "------------------------------------------------------"
    echo -e "  Frontend UI:          ${BLUE}http://localhost:3000${NC}"
    echo -e "  Backend REST API:     ${BLUE}http://localhost:8080/api/recipes${NC}"
    echo -e "  Actuator Metrics:     ${BLUE}http://localhost:8080/actuator/prometheus${NC}"
    echo -e "  Prometheus Scraper:   ${BLUE}http://localhost:9090${NC}"
    echo -e "  Grafana Dashboard:    ${BLUE}http://localhost:3001${NC} (admin / admin)"
    echo -e "------------------------------------------------------"

elif [ "$MODE" == "k8s" ]; then
    echo -e "\n${YELLOW}Applying Kubernetes manifests via Kustomize...${NC}"
    kubectl apply -k k8s/

    echo -e "\n${YELLOW}Waiting for Kubernetes Pods rollout in namespace 'recipe-app'...${NC}"
    kubectl rollout status deployment/mysql-deployment -n recipe-app --timeout=180s
    kubectl rollout status deployment/backend-deployment -n recipe-app --timeout=180s
    kubectl rollout status deployment/frontend-deployment -n recipe-app --timeout=180s
    kubectl rollout status deployment/prometheus-deployment -n recipe-app --timeout=180s
    kubectl rollout status deployment/grafana-deployment -n recipe-app --timeout=180s

    echo -e "\n${GREEN}✓ Kubernetes rollout completed successfully!${NC}"
    echo -e "\n${BLUE}Active Services in 'recipe-app':${NC}"
    kubectl get services -n recipe-app -o wide

    echo -e "\n${BLUE}NodePort Access Points (on cluster node IP):${NC}"
    echo -e "• Frontend Web:       http://<NODE-IP>:30080"
    echo -e "• Prometheus UI:      http://<NODE-IP>:30090"
    echo -e "• Grafana Dashboard:  http://<NODE-IP>:30091"
else
    echo -e "${RED}Invalid mode '${MODE}'. Choose 'compose' or 'k8s'.${NC}"
    exit 1
fi
