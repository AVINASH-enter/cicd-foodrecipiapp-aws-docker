#!/usr/bin/env bash
# ==============================================================================
# GourmetCloud - Server & Cluster Management CLI Utility
# ==============================================================================

set -euo pipefail

COMMAND="${1:-help}"
PARAM="${2:-}"

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

case "$COMMAND" in
    status)
        echo -e "${BLUE}=== Docker Compose Containers ===${NC}"
        docker compose ps || true

        if command -v kubectl &> /dev/null; then
            echo -e "\n${BLUE}=== Kubernetes Pods (namespace: recipe-app) ===${NC}"
            kubectl get pods -n recipe-app -o wide 2>/dev/null || echo "Namespace recipe-app not deployed."
            echo -e "\n${BLUE}=== Kubernetes Services ===${NC}"
            kubectl get svc -n recipe-app 2>/dev/null || true
        fi
        ;;

    logs)
        SERVICE="${PARAM:-backend}"
        echo -e "${YELLOW}Streaming logs for service: ${SERVICE}...${NC}"
        docker compose logs -f "$SERVICE"
        ;;

    backup-db)
        BACKUP_DIR="./backups"
        mkdir -p "$BACKUP_DIR"
        TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
        FILE="${BACKUP_DIR}/recipe_db_${TIMESTAMP}.sql"
        echo -e "${YELLOW}Exporting MySQL database backup to ${FILE}...${NC}"
        docker compose exec -T mysql mysqldump -u recipe_user -precipe_password recipe_db > "$FILE"
        echo -e "${GREEN}✓ Database backup completed successfully: ${FILE}${NC}"
        ;;

    restore-db)
        if [ -z "$PARAM" ]; then
            echo -e "${RED}Error: Please specify the SQL backup file to restore.${NC}"
            echo "Usage: ./scripts/manage.sh restore-db ./backups/filename.sql"
            exit 1
        fi
        echo -e "${YELLOW}Restoring database from ${PARAM}...${NC}"
        docker compose exec -T mysql mysql -u recipe_user -precipe_password recipe_db < "$PARAM"
        echo -e "${GREEN}✓ Database restored successfully!${NC}"
        ;;

    test-network)
        echo -e "${BLUE}=== Testing Inter-Service Networking & Resolution ===${NC}"
        echo -n "1. Checking Frontend to Backend resolution: "
        if docker compose exec -T frontend wget -q -O - http://backend-service:8080/api/status > /dev/null 2>&1; then
            echo -e "${GREEN}[SUCCESS]${NC}"
        else
            echo -e "${RED}[FAILED]${NC}"
        fi

        echo -n "2. Checking Backend to MySQL connectivity: "
        if docker compose exec -T backend nc -z -v -w5 mysql 3306 2>/dev/null || \
           docker compose exec -T backend wget -q -O - http://localhost:8080/actuator/health | grep -q "UP"; then
            echo -e "${GREEN}[SUCCESS]${NC}"
        else
            echo -e "${RED}[FAILED]${NC}"
        fi

        echo -n "3. Checking Prometheus Scrape Target: "
        if docker compose exec -T prometheus wget -q -O - http://backend:8080/actuator/prometheus > /dev/null 2>&1; then
            echo -e "${GREEN}[SUCCESS]${NC}"
        else
            echo -e "${RED}[FAILED]${NC}"
        fi
        ;;

    clean)
        echo -e "${YELLOW}Stopping and removing all stack containers and volumes...${NC}"
        docker compose down -v --remove-orphans
        if command -v kubectl &> /dev/null; then
            kubectl delete namespace recipe-app --ignore-not-found=true
        fi
        echo -e "${GREEN}✓ Environment cleaned up.${NC}"
        ;;

    *)
        echo -e "${BLUE}GourmetCloud Operations CLI${NC}"
        echo "Usage: ./scripts/manage.sh [command]"
        echo ""
        echo "Commands:"
        echo "  status            Display container and pod runtime statuses"
        echo "  logs <service>    Stream logs for a service (e.g. backend, frontend, mysql, prometheus)"
        echo "  backup-db         Create timestamped MySQL dump in ./backups"
        echo "  restore-db <file> Restore MySQL database from specified .sql dump"
        echo "  test-network      Verify inter-service DNS resolution and HTTP endpoints"
        echo "  clean             Tear down containers, k8s namespace, and remove storage volumes"
        ;;
esac
