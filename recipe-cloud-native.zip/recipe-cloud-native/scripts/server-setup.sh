#!/usr/bin/env bash
# ==============================================================================
# GourmetCloud - Linux Server Management & Cloud-Native Host Provisioning
# Target OS: Ubuntu 22.04 / 24.04 LTS or Debian 12
# ==============================================================================

set -euo pipefail

# Visual formatting
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}======================================================${NC}"
echo -e "${BLUE}  Starting Cloud-Native Server Hardening & Setup      ${NC}"
echo -e "${BLUE}======================================================${NC}"

# Check root privileges
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}Error: This script must be run as root (sudo ./server-setup.sh)${NC}"
  exit 1
fi

# 1. System Update & Dependencies
echo -e "\n${GREEN}[1/6] Updating system packages and repositories...${NC}"
apt-get update -y && apt-get upgrade -y
apt-get install -y \
    apt-transport-https \
    ca-certificates \
    curl \
    gnupg \
    lsb-release \
    software-properties-common \
    ufw \
    net-tools \
    htop \
    jq \
    git

# 2. Kernel & Networking Tuning for Containers and Kubernetes
echo -e "\n${GREEN}[2/6] Configuring Linux Kernel sysctl parameters for container networking...${NC}"
cat <<EOF > /etc/sysctl.d/99-cloud-native.conf
# Enable IPv4 packet forwarding for bridge networks and Kubernetes CNI
net.ipv4.ip_forward = 1
net.bridge.bridge-nf-call-iptables = 1
net.bridge.bridge-nf-call-ip6tables = 1

# Increase system file descriptors and socket buffers
fs.file-max = 2097152
net.core.somaxconn = 65535
vm.max_map_count = 262144
EOF

# Load bridge netfilter module
modprobe br_netfilter || true
modprobe overlay || true
sysctl --system > /dev/null

# 3. UFW Firewall Configuration
echo -e "\n${GREEN}[3/6] Setting up UFW firewall rules...${NC}"
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp comment 'SSH Remote Access'
ufw allow 80/tcp comment 'HTTP Web Frontend'
ufw allow 443/tcp comment 'HTTPS Ingress'
ufw allow 3000/tcp comment 'React Development Server'
ufw allow 8080/tcp comment 'Spring Boot REST API'
ufw allow 9090/tcp comment 'Prometheus Metrics Server'
ufw allow 3001/tcp comment 'Grafana Visualization'
ufw allow 6443/tcp comment 'Kubernetes API Server'
ufw allow 30000:32767/tcp comment 'Kubernetes NodePort Range'
# Enable UFW without interactive prompt
echo "y" | ufw enable || true

# 4. Install Docker Engine & Containerd
echo -e "\n${GREEN}[4/6] Installing Docker Engine & containerd runtime...${NC}"
if ! command -v docker &> /dev/null; then
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
    chmod a+r /etc/apt/keyrings/docker.asc

    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
      $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
      tee /etc/apt/sources.list.d/docker.list > /dev/null

    apt-get update -y
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    
    systemctl enable docker
    systemctl start docker
    echo -e "${GREEN}✓ Docker Engine successfully installed.${NC}"
else
    echo -e "${YELLOW}✓ Docker already installed ($(docker --version)).${NC}"
fi

# 5. Install Kubectl
echo -e "\n${GREEN}[5/6] Installing kubectl CLI...${NC}"
if ! command -v kubectl &> /dev/null; then
    curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.31/deb/Release.key | gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg
    echo 'deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.31/deb/ /' | tee /etc/apt/sources.list.d/kubernetes.list
    apt-get update -y
    apt-get install -y kubectl
    echo -e "${GREEN}✓ kubectl installed successfully.${NC}"
else
    echo -e "${YELLOW}✓ kubectl already installed.${NC}"
fi

# 6. Service Verification & User Perms
echo -e "\n${GREEN}[6/6] Verifying system daemon health...${NC}"
if [ -n "${SUDO_USER:-}" ]; then
    usermod -aG docker "$SUDO_USER"
    echo -e "${GREEN}✓ Added user $SUDO_USER to docker group.${NC}"
fi

echo -e "\n${BLUE}======================================================${NC}"
echo -e "${GREEN} Server Setup Completed Successfully!                ${NC}"
echo -e "${BLUE}======================================================${NC}"
echo -e "You can now run:${YELLOW} ./scripts/deploy.sh ${NC}to launch the application."
