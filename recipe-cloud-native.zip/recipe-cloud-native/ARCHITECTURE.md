# GourmetCloud - Cloud-Native System Architecture

## 1. System Architecture Overview

GourmetCloud is an enterprise-grade, cloud-native distributed food recipe platform designed with a microservices-aligned architecture, containerized with Docker, orchestrated via Kubernetes, monitored with Prometheus and Grafana, and automated via GitHub Actions CI/CD.

```mermaid
flowchart TD
    subgraph Client["External Clients & Traffic"]
        Browser["User Browser (Web / Mobile)"]
        CLI["Ops / Shell Management CLI"]
    end

    subgraph IngressLayer["Ingress & Edge Routing"]
        Ingress["Kubernetes NGINX Ingress Controller\n(Port 80 / 443)"]
    end

    subgraph AppNamespace["Kubernetes Namespace: recipe-app"]
        subgraph FrontendTier["Frontend Tier (2 Replicas)"]
            FrontendPod1["Frontend Pod 1\n(React 18 + NGINX)"]
            FrontendPod2["Frontend Pod 2\n(React 18 + NGINX)"]
            FrontendSvc["Frontend Service\n(NodePort: 30080 / Port: 80)"]
        end

        subgraph BackendTier["Backend API Tier (2 Replicas)"]
            BackendPod1["Backend Pod 1\n(Spring Boot 3 / Java 21)"]
            BackendPod2["Backend Pod 2\n(Spring Boot 3 / Java 21)"]
            BackendSvc["Backend Service\n(ClusterIP: 8080)"]
        end

        subgraph DatabaseTier["Database Tier (Stateful)"]
            MySQLPod["MySQL 8.0 Server Pod"]
            MySQLSvc["MySQL Service\n(ClusterIP: 3306)"]
            PVC["PersistentVolumeClaim\n(mysql-pvc: 2Gi)"]
        end

        subgraph MonitoringTier["Observability & Telemetry"]
            PrometheusPod["Prometheus Server Pod\n(Port: 9090)"]
            GrafanaPod["Grafana Dashboard Pod\n(Port: 3000 -> 30091)"]
        end
    end

    Browser --> Ingress
    Ingress -->|/api/*| BackendSvc
    Ingress -->|/*| FrontendSvc
    FrontendPod1 -->|proxy /api| BackendSvc
    FrontendPod2 -->|proxy /api| BackendSvc
    BackendSvc --> BackendPod1
    BackendSvc --> BackendPod2
    BackendPod1 -->|JDBC:3306| MySQLSvc
    BackendPod2 -->|JDBC:3306| MySQLSvc
    MySQLSvc --> MySQLPod
    MySQLPod --> PVC

    PrometheusPod -->|Scrape /actuator/prometheus| BackendPod1
    PrometheusPod -->|Scrape /actuator/prometheus| BackendPod2
    GrafanaPod -->|PromQL queries| PrometheusPod
```

---

## 2. Networking Architecture & Inter-Service Communication

| Component | Target Port | Protocol | Scope | Service Discovery DNS |
| :--- | :--- | :--- | :--- | :--- |
| **Frontend UI** | `80` (NodePort `30080`) | HTTP | Public / Cluster | `frontend-service.recipe-app.svc.cluster.local` |
| **Backend REST API** | `8080` | HTTP | Internal Cluster | `backend-service.recipe-app.svc.cluster.local` |
| **MySQL Database** | `3306` | TCP/MySQL | Internal Cluster | `mysql-service.recipe-app.svc.cluster.local` |
| **Prometheus** | `9090` (NodePort `30090`) | HTTP | Cluster / Admin | `prometheus-service.recipe-app.svc.cluster.local` |
| **Grafana** | `3000` (NodePort `30091`) | HTTP | Cluster / Admin | `grafana-service.recipe-app.svc.cluster.local` |

### Networking Flow:
1. **Client Request**: Browser requests hit the **NGINX Ingress Controller**.
2. **Reverse Proxying**:
   - Web assets are served by the React static bundle hosted in Alpine NGINX.
   - API calls (`/api/**`) route directly to `backend-service:8080`.
3. **Database Connectivity**:
   - Backend connects via HikariCP Connection Pool to `mysql-service:3306`.
   - Automatic connection retry and validation query execution (`SELECT 1`).
4. **Resilience & Probes**:
   - Kubernetes runs `livenessProbe` at `/actuator/health/liveness` (checks if container is responsive).
   - Kubernetes runs `readinessProbe` at `/actuator/health/readiness` (checks DB availability before routing traffic).

---

## 3. Telemetry & Monitoring Architecture

```mermaid
sequenceDiagram
    autonumber
    participant App as Spring Boot Actuator
    participant Micrometer as Micrometer Engine
    participant Prom as Prometheus Server
    participant Grafana as Grafana Dashboard
    participant User as SRE / DevOps Engineer

    App->>Micrometer: Increment recipes_created_total
    App->>Micrometer: Record HTTP latency in histogram
    Prom->>App: GET /actuator/prometheus (every 15s)
    App-->>Prom: Plaintext OpenMetrics payload
    Prom->>Prom: Store in TSDB (Time Series Database)
    User->>Grafana: Access Dashboard (Port 3001 / 30091)
    Grafana->>Prom: PromQL Query (e.g. rate(recipes_created_total[1m]))
    Prom-->>Grafana: Return metric vectors
    Grafana-->>User: Render real-time time-series panels
```

### Metrics Tracked:
- **Application Custom Business Metrics**:
  - `recipes_created_total`: Counter incremented whenever a recipe is published.
  - `recipes_deleted_total`: Counter tracking recipe deletions.
  - `recipe_searches_total`: Counter tracking search query volume.
  - `recipe_operations_duration_seconds`: Histogram measuring execution latency.
- **System & JVM Metrics**:
  - `http_server_requests_seconds`: Throughput, status codes (2xx, 4xx, 5xx), and P95 latency.
  - `jvm_memory_used_bytes`: Real-time JVM heap and non-heap memory consumption.
  - `hikaricp_connections_active`: Database connection pool saturation.

---

## 4. CI/CD Automation Pipeline (GitHub Actions)

```mermaid
flowchart LR
    Commit["Git Push\n(main/master)"] --> CI_Backend["Backend CI\n(Java 21 / Maven)"]
    Commit --> CI_Frontend["Frontend CI\n(Node 20 / Vite)"]
    
    CI_Backend --> DockerBuild["Docker Buildx\n(Multi-arch)"]
    CI_Frontend --> DockerBuild
    
    DockerBuild --> GHCR["Push to GHCR\n(ghcr.io)"]
    GHCR --> SecurityScan["Trivy Security\nVulnerability Scan"]
    SecurityScan --> CD_K8s["Rolling Update\nKubernetes Cluster"]
```

---

## 5. Linux Server Hardening & Shell Scripting

The application includes automated Bash scripts for production Linux environments:
- `scripts/server-setup.sh`: Configures UFW firewall, installs Docker Engine, sets Linux kernel parameters (`net.ipv4.ip_forward=1`, `fs.file-max`).
- `scripts/deploy.sh`: Orchestrates one-click deployment for Docker Compose or Kubernetes.
- `scripts/manage.sh`: CLI for daily administrative tasks (backups, log streaming, network diagnostics).
