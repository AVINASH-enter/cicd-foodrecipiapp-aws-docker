# GourmetCloud - Cloud-Native Food Recipe Application 🍳☁️

[![CI/CD Pipeline](https://img.shields.io/badge/CI%2FCD-GitHub%20Actions-blue?logo=github-actions)](.github/workflows/ci-cd.yaml)
[![React](https://img.shields.io/badge/Frontend-React%2018%20%2B%20Vite-61DAFB?logo=react)](frontend)
[![Spring Boot](https://img.shields.io/badge/Backend-Spring%20Boot%203.3%20(Java%2021)-6DB33F?logo=springboot)](backend)
[![MySQL](https://img.shields.io/badge/Database-MySQL%208.0-4479A1?logo=mysql)](k8s/mysql-deployment.yaml)
[![Docker](https://img.shields.io/badge/Container-Docker%20Multi--Stage-2496ED?logo=docker)](docker-compose.yml)
[![Kubernetes](https://img.shields.io/badge/Orchestration-Kubernetes-326CE5?logo=kubernetes)](k8s)
[![Prometheus](https://img.shields.io/badge/Monitoring-Prometheus-E6522C?logo=prometheus)](monitoring/prometheus.yml)
[![Grafana](https://img.shields.io/badge/Visualization-Grafana-F46800?logo=grafana)](monitoring/grafana)

A production-grade, cloud-native Food Recipe platform featuring a **React 18** responsive interface, a **Spring Boot 3 (Java 21)** REST API backend, **MySQL 8.0** persistence, multi-stage **Docker** containerization, **Kubernetes** orchestration with auto-healing and scaling, comprehensive **Prometheus & Grafana** observability, Linux server automation scripts, and an automated **GitHub Actions** CI/CD pipeline.

---

## 🌟 Key Features

- **Gourmet Recipe Catalog**: Browse curated recipes across Breakfast, Lunch, Dinner, Dessert, Vegan, and Quick & Easy categories.
- **Interactive Cooking Checklist**: Tick off ingredients step-by-step directly from the recipe view modal.
- **Full Recipe Management (CRUD)**: Create, edit, search, filter, and delete recipes with validation and image preview.
- **Production Spring Boot 3 & Java 21**: REST API structured with Controllers, Services, DTOs, JPA Entities, and Global Exception Handlers.
- **Cloud-Native Actuator & Probes**: Exposes Kubernetes liveness (`/actuator/health/liveness`) and readiness (`/actuator/health/readiness`) probes.
- **Prometheus & Grafana Monitoring**: Scrapes custom business metrics (`recipes_created_total`, `recipe_searches_total`), HTTP P95 latency, HikariCP database pool stats, and JVM memory.
- **Kubernetes Production Ready**: Multi-replica Deployments, Services, ConfigMaps, Secrets, PVCs, Ingress, and Kustomize integration (`k8s/`).
- **Automated CI/CD**: GitHub Actions workflow running tests, building multi-arch Docker images, scanning vulnerabilities with Trivy, and rolling updates.
- **Linux Server Management Scripts**: Complete bash automation for OS hardening, UFW firewall, Docker/k8s setup, and backup management.

---

## 🏗️ Architecture & Component Overview

```
recipe-cloud-native/
├── .github/workflows/
│   └── ci-cd.yaml                   # GitHub Actions pipeline (Test, Build, Push, Scan, Deploy)
├── backend/                         # Spring Boot 3.3.4 (Java 21) REST API
│   ├── src/main/java/com/recipe/app/
│   │   ├── config/                  # CORS and Micrometer Prometheus metrics config
│   │   ├── controller/              # RecipeController and HealthController
│   │   ├── dto/                     # RecipeRequest, RecipeResponse, ApiResponse
│   │   ├── exception/               # GlobalExceptionHandler, ResourceNotFoundException
│   │   ├── loader/                  # DataLoader (initial recipe seed)
│   │   ├── model/                   # Recipe JPA entity and Category enum
│   │   ├── repository/              # Spring Data JPA RecipeRepository
│   │   └── service/                 # RecipeService & RecipeServiceImpl
│   ├── src/main/resources/
│   │   └── application.yml          # Actuator, HikariCP, and MySQL configs
│   ├── src/test/java/               # Unit test suite with Mockito
│   ├── Dockerfile                   # Multi-stage build (Temurin 21 JDK -> Alpine JRE)
│   └── pom.xml                      # Maven project configuration
├── frontend/                        # React 18 + Vite + Tailwind CSS
│   ├── src/
│   │   ├── components/              # Navbar, RecipeCard, Modals, CategoryFilter
│   │   ├── services/api.js          # REST client with automatic fallback
│   │   ├── App.jsx                  # Main Application logic
│   │   └── main.jsx
│   ├── nginx.conf                   # Nginx reverse proxy & SPA configuration
│   └── Dockerfile                   # Multi-stage build (Node 20 -> Alpine Nginx)
├── k8s/                             # Kubernetes Manifests
│   ├── namespace.yaml               # Namespace: recipe-app
│   ├── mysql-secret-pvc.yaml        # MySQL Secret & PersistentVolumeClaim
│   ├── mysql-deployment.yaml        # MySQL Deployment & ClusterIP Service
│   ├── backend-configmap.yaml       # Backend ConfigMap
│   ├── backend-deployment.yaml      # Backend Deployment (2 replicas) & Service
│   ├── frontend-deployment.yaml     # Frontend Deployment (2 replicas) & NodePort Service
│   ├── ingress.yaml                 # Nginx Ingress routing
│   ├── prometheus-k8s.yaml          # Prometheus RBAC, ConfigMap, Deployment & Service
│   ├── grafana-k8s.yaml             # Grafana Deployment, Service & Datasource
│   └── kustomization.yaml           # Unified Kustomize deployment manifest
├── monitoring/                      # Monitoring configurations
│   ├── prometheus.yml               # Scrape configurations for backend and k8s
│   └── grafana/                     # Provisioned datasources and dashboard JSON
├── scripts/                         # Linux & Shell Management Scripts
│   ├── server-setup.sh              # Ubuntu/Debian OS setup, firewall & container runtime
│   ├── deploy.sh                    # Automated bash deployment (compose or k8s)
│   ├── manage.sh                    # Operations CLI (logs, backup-db, test-network)
│   └── deploy.ps1                   # Windows PowerShell deployment script
├── docker-compose.yml               # Local orchestration for all 5 services
└── ARCHITECTURE.md                  # Comprehensive Architecture document
```

---

## 🚀 Quick Start Guide

### Option 1: Run with Docker Compose (Recommended for Local Testing)

Start the entire stack (MySQL, Backend, Frontend, Prometheus, Grafana) with a single command:

```bash
docker compose up -d --build
```
*(Or on Windows PowerShell: `.\scripts\deploy.ps1`)*

Once started, access the services:
| Service | URL | Credentials / Notes |
| :--- | :--- | :--- |
| **Frontend Web App** | [http://localhost:3000](http://localhost:3000) | Full Recipe UI |
| **Backend REST API** | [http://localhost:8080/api/recipes](http://localhost:8080/api/recipes) | JSON REST endpoints |
| **Prometheus Metrics** | [http://localhost:8080/actuator/prometheus](http://localhost:8080/actuator/prometheus) | Raw Actuator metrics |
| **Prometheus Dashboard** | [http://localhost:9090](http://localhost:9090) | PromQL queries |
| **Grafana Visualizations** | [http://localhost:3001](http://localhost:3001) | **User:** `admin` / **Pass:** `admin` |

---

### Option 2: Deploy on Kubernetes

Deploy the entire cluster configuration to any Kubernetes cluster (Minikube, k3s, EKS, GKE, AKS) with Kustomize:

```bash
# 1. Apply all manifests in the recipe-app namespace
kubectl apply -k k8s/

# 2. Check rollout progress
kubectl rollout status deployment/backend-deployment -n recipe-app
kubectl rollout status deployment/frontend-deployment -n recipe-app

# 3. View running pods and services
kubectl get pods,svc -n recipe-app
```

Access via NodePort (on cluster node IP):
- **Frontend UI**: `http://<NODE-IP>:30080`
- **Prometheus**: `http://<NODE-IP>:30090`
- **Grafana**: `http://<NODE-IP>:30091`

---

## 📊 Observability & Monitoring

The backend exposes real-time application metrics at `/actuator/prometheus`.

### Custom Business Metrics
- `recipes_created_total`: Number of published recipes.
- `recipes_deleted_total`: Track removed recipes.
- `recipe_searches_total`: Search query count.
- `recipe_operations_duration_seconds`: Histogram measuring execution latency.

### Pre-configured Grafana Dashboard
Access Grafana at `http://localhost:3001` (user: `admin`, pass: `admin`). The **"Recipe Cloud-Native Telemetry"** dashboard is preloaded with:
1. **Total Recipes Created Counter**
2. **Recipe Search Activity Counter**
3. **Active MySQL HikariCP Connection Count**
4. **HTTP Requests Per Second by URI & Status Code**
5. **P95 Latency Percentiles**
6. **JVM Heap Memory Usage (Heap Used vs Max)**
7. **JVM GC Pause Duration**

---

## 🛠️ Linux & Shell Server Management

The `scripts/` directory provides shell utilities for administering the deployment:

```bash
# 1. Prepare and harden a clean Ubuntu/Debian server
sudo chmod +x scripts/*.sh
sudo ./scripts/server-setup.sh

# 2. Deploy or update stack
./scripts/deploy.sh compose    # or ./scripts/deploy.sh k8s

# 3. Stream backend container logs
./scripts/manage.sh logs backend

# 4. Perform live database backup
./scripts/manage.sh backup-db

# 5. Verify inter-container DNS and networking
./scripts/manage.sh test-network
```

---

## 🔄 CI/CD Automation (GitHub Actions)

The pipeline defined in [`.github/workflows/ci-cd.yaml`](.github/workflows/ci-cd.yaml) executes automatically on push to `main`:
1. **Backend CI**: Compiles Java 21, executes unit tests via Maven, and uploads Surefire test artifacts.
2. **Frontend CI**: Validates dependencies and generates production Vite static assets.
3. **Docker Build & Push**: Uses Docker Buildx with layer caching to push container images to GitHub Container Registry (`ghcr.io`).
4. **Security Vulnerability Scan**: Scans images with Aqua Trivy for `HIGH` and `CRITICAL` CVEs.
5. **Kubernetes Deployment**: Performs rolling deployment updates to the cluster with SHA tags.

---

## 📡 REST API Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/recipes` | List all recipes (optional `?category=DINNER&keyword=salmon`) |
| `GET` | `/api/recipes/{id}` | Get recipe by ID |
| `POST` | `/api/recipes` | Create a new recipe |
| `PUT` | `/api/recipes/{id}` | Update existing recipe |
| `DELETE` | `/api/recipes/{id}` | Remove recipe |
| `GET` | `/api/recipes/stats` | Get recipe totals and category distribution |
| `GET` | `/api/status` | Application health and database status |
| `GET` | `/actuator/prometheus` | Prometheus metrics scrape target |

---

## 📄 License
This project is open-source under the MIT License.
